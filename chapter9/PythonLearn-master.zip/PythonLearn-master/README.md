# PythonLearn
# 第一部分：Python基础
## chapter1 常用函数使用
## chapter3 函数
## chapter4 列表
## chapter5 字典和结构化数据
## chapter6 字符串操作
# 第二部分：自动化任务
## chapter7 模式匹配与正则表达式