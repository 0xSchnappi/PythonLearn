# 单行注释
'''
多行注释
'''
print("Please input your name:")
yourName = input()
print("Your name is:" + yourName)
print("Your name length is:" + str(len(yourName)))
# 强制转换
print("str():" + str(2) + "\nint():" + str(int('5')) + "\nfloat():" + str(float('3.14')))